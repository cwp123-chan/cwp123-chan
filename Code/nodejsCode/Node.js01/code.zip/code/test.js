var sum = 0;

for (var i = 0; i < 10; i++) {
    sum += 5;
}

console.log(sum);